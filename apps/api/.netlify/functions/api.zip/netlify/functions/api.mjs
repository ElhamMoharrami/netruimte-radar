
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// apps/api/src/app.ts
import { Hono as Hono5 } from "hono";
import { cors } from "hono/cors";

// apps/api/src/routes/opportunities.ts
import { Hono } from "hono";
function opportunitiesRoutes(ctx) {
  const app = new Hono();
  app.get("/opportunities", async (c) => {
    const list = await ctx.repos.opportunities.list();
    return c.json({ data: list });
  });
  app.get("/opportunities/:id", async (c) => {
    const id = c.req.param("id");
    const opportunity = await ctx.repos.opportunities.findById(id);
    if (!opportunity) return c.json({ error: "not_found" }, 404);
    const company = await ctx.repos.companies.findById(opportunity.companyId);
    const signals = await Promise.all(
      opportunity.signalIds.map((sid) => ctx.repos.signals.findById(sid))
    );
    const evidence = await ctx.repos.evidence.listByCompany(opportunity.companyId);
    const decisions = await ctx.repos.decisions.listByOpportunity(opportunity.id);
    return c.json({
      opportunity,
      company,
      signals: signals.filter((s) => s !== null),
      evidence,
      decisions
    });
  });
  app.get("/opportunities/:id/activity", async (c) => {
    const id = c.req.param("id");
    const opportunity = await ctx.repos.opportunities.findById(id);
    if (!opportunity) return c.json({ error: "not_found" }, 404);
    const activity = await ctx.repos.activity.listByOpportunity(id);
    return c.json({ opportunityId: id, activity });
  });
  app.get("/opportunities/:id/dossier", async (c) => {
    const id = c.req.param("id");
    const opportunity = await ctx.repos.opportunities.findById(id);
    if (!opportunity) return c.json({ error: "not_found" }, 404);
    const dossier = await ctx.dossierService.getForOpportunity(id);
    if (!dossier) return c.json({ error: "dossier_unavailable" }, 404);
    return c.json({ dossier });
  });
  app.get("/opportunities/:id/history", async (c) => {
    const id = c.req.param("id");
    const opportunity = await ctx.repos.opportunities.findById(id);
    if (!opportunity) return c.json({ error: "not_found" }, 404);
    const decisions = await ctx.repos.decisions.listByOpportunity(id);
    const activity = await ctx.repos.activity.listByOpportunity(id);
    const reassessments = activity.filter((a) => a.eventType === "OPPORTUNITY_REASSESSED").map((a) => ({
      at: a.createdAt,
      message: a.message,
      ...a.metadata
    }));
    return c.json({ opportunityId: id, decisions, reassessments });
  });
  return app;
}
function activityRoutes(ctx) {
  const app = new Hono();
  app.get("/activity/recent", async (c) => {
    const limit = Math.max(1, Math.min(500, Number(c.req.query("limit") ?? 100)));
    const activity = await ctx.repos.activity.listRecent(limit);
    return c.json({ data: activity });
  });
  return app;
}

// apps/api/src/routes/runs.ts
import { Hono as Hono2 } from "hono";
function runsRoutes(ctx) {
  const app = new Hono2();
  app.post("/runs/demo", async (c) => {
    const offline = c.req.query("offline") === "true";
    const service = offline ? ctx.buildOfflineRunService() : ctx.runService;
    const summary = await service.run({ trigger: "demo", notes: offline ? "offline mode" : void 0 });
    return c.json({ wiring: ctx.wiring, summary });
  });
  app.post("/runs/scheduled", async (c) => {
    if (!ctx.serviceToken) {
      return c.json({ error: "scheduled_endpoint_disabled" }, 503);
    }
    const provided = c.req.header("x-service-token");
    if (provided !== ctx.serviceToken) {
      return c.json({ error: "unauthorized" }, 401);
    }
    const offline = c.req.query("offline") === "true";
    const service = offline ? ctx.buildOfflineRunService() : ctx.runService;
    const trigger = "scheduled";
    const summary = await service.run({ trigger, notes: offline ? "offline mode" : void 0 });
    return c.json({ wiring: ctx.wiring, summary });
  });
  app.get("/runs", async (c) => {
    const limit = Math.max(1, Math.min(500, Number(c.req.query("limit") ?? 100)));
    const data = await ctx.repos.runs.list(limit);
    return c.json({ data });
  });
  app.get("/wiring", (c) => c.json(ctx.wiring));
  return app;
}

// apps/api/src/routes/demo.ts
import { Hono as Hono3 } from "hono";
import {
  AutonomousRunService,
  DemoGridContextProvider,
  DemoSourceDiscoveryProvider,
  LocalAutomationProvider,
  OpportunityScoringService,
  PolicyEngine,
  RuleBasedEvidenceExtractor
} from "@netruimte/core";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
var here = dirname(fileURLToPath(import.meta.url));
var DEMO_SOURCES_DIR = resolve(here, "../../../../data/demo/sources");
function demoRoutes(ctx) {
  const app = new Hono3();
  app.use("/demo/*", async (c, next) => {
    if (!ctx.demoMode) return c.json({ error: "demo_disabled" }, 403);
    await next();
  });
  app.post("/demo/reset", async (c) => {
    await ctx.resetDb();
    return c.json({ ok: true });
  });
  app.post("/demo/overnight-scan", async (c) => {
    const summary = await ctx.runService.run({
      trigger: "scheduled",
      notes: "demo overnight scan"
    });
    return c.json({ wiring: ctx.wiring, summary });
  });
  app.post("/demo/inject-conflict/:opportunityId", async (c) => {
    const oppId = c.req.param("opportunityId");
    const opportunity = await ctx.repos.opportunities.findById(oppId);
    if (!opportunity) return c.json({ error: "opportunity_not_found" }, 404);
    const company = await ctx.repos.companies.findById(opportunity.companyId);
    if (!company) return c.json({ error: "company_not_found" }, 404);
    const name = company.name;
    const conflictingSource = {
      url: `https://conflict.example/${encodeURIComponent(name)}-${Date.now()}`,
      title: `${name} schrapt eerder aangekondigde plannen`,
      rawText: `${name} BV heeft vandaag laten weten in ${company.city ?? "Nederland"} dat het bedrijf voor 2026 kiest voor een kleine duurzaamheidsupdate. Het bedrijf gaat verduurzamen met LED-verlichting in de kantoorruimte en verwacht geen wijzigingen aan de vloot of het pand.`,
      discoveredAt: (/* @__PURE__ */ new Date()).toISOString(),
      publishedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sourceType: "company_news",
      provider: "demo-conflict-injector"
    };
    const service = new AutonomousRunService({
      repos: ctx.repos,
      sources: singletonProvider("demo-conflict-injector", [conflictingSource]),
      extractor: new RuleBasedEvidenceExtractor(),
      grid: new DemoGridContextProvider(),
      scoring: new OpportunityScoringService(),
      policy: new PolicyEngine(),
      automation: new LocalAutomationProvider()
    });
    const summary = await service.run({ trigger: "demo", notes: `inject conflict for ${name}` });
    return c.json({ summary });
  });
  app.post("/demo/simulate/apify-fail", async (c) => {
    const failing = {
      name: "apify-fail-sim",
      async discover() {
        throw new Error("simulated Apify timeout");
      }
    };
    const service = new AutonomousRunService({
      repos: ctx.repos,
      sources: failing,
      extractor: new RuleBasedEvidenceExtractor(),
      grid: new DemoGridContextProvider(),
      scoring: new OpportunityScoringService(),
      policy: new PolicyEngine(),
      automation: new LocalAutomationProvider()
    });
    const summary = await service.run({ trigger: "demo", notes: "simulate Apify failure" });
    return c.json({ summary });
  });
  app.post("/demo/simulate/n8n-fail", async (c) => {
    const failingAutomation = {
      name: "n8n-fail-sim",
      async dispatch(_p) {
        throw new Error("simulated n8n webhook 502");
      }
    };
    const service = new AutonomousRunService({
      repos: ctx.repos,
      sources: new DemoSourceDiscoveryProvider(DEMO_SOURCES_DIR),
      extractor: new RuleBasedEvidenceExtractor(),
      grid: new DemoGridContextProvider(),
      scoring: new OpportunityScoringService(),
      policy: new PolicyEngine(),
      automation: failingAutomation
    });
    const summary = await service.run({ trigger: "demo", notes: "simulate n8n failure" });
    return c.json({ summary });
  });
  return app;
}
function singletonProvider(name, docs) {
  return {
    name,
    async discover() {
      return docs;
    }
  };
}

// apps/api/src/routes/gridEvents.ts
import { Hono as Hono4 } from "hono";
function gridEventsRoutes(ctx) {
  const app = new Hono4();
  app.get("/grid-events", async (c) => {
    const limit = Math.max(1, Math.min(500, Number(c.req.query("limit") ?? 100)));
    const data = await ctx.repos.gridEvents.list(limit);
    return c.json({ data });
  });
  app.get("/grid-events/:id", async (c) => {
    const id = c.req.param("id");
    const event = await ctx.repos.gridEvents.findById(id);
    if (!event) return c.json({ error: "not_found" }, 404);
    return c.json({ event });
  });
  return app;
}

// apps/api/src/app.ts
function createApp(ctx) {
  const app = new Hono5();
  app.use("*", cors());
  app.get(
    "/health",
    (c) => c.json({
      status: "ok",
      service: "netruimte-radar-api",
      demoMode: ctx.demoMode,
      time: (/* @__PURE__ */ new Date()).toISOString()
    })
  );
  app.route("/api", opportunitiesRoutes(ctx));
  app.route("/api", activityRoutes(ctx));
  app.route("/api", runsRoutes(ctx));
  app.route("/api", demoRoutes(ctx));
  app.route("/api", gridEventsRoutes(ctx));
  return app;
}

// apps/api/src/context.ts
import { fileURLToPath as fileURLToPath2 } from "node:url";
import { dirname as dirname3, resolve as resolve3 } from "node:path";
import { newId } from "@netruimte/shared";
import {
  ApifySourceDiscoveryProvider,
  AutonomousRunService as AutonomousRunService2,
  DemoGridContextProvider as DemoGridContextProvider2,
  DemoSourceDiscoveryProvider as DemoSourceDiscoveryProvider2,
  DisabledAutomationProvider,
  LocalAutomationProvider as LocalAutomationProvider2,
  N8nAutomationClient,
  NETBEHEER_NL_SNAPSHOT_AT,
  NetbeheerNlGridContextProvider,
  OpportunityDossierService,
  PolicyEngine as PolicyEngine2,
  OpportunityScoringService as OpportunityScoringService2,
  RuleBasedEvidenceExtractor as RuleBasedEvidenceExtractor2,
  chooseEvidenceExtractor
} from "@netruimte/core";

// apps/api/src/persistence/sqlClient.ts
import { createRequire } from "node:module";
import { mkdirSync } from "node:fs";
import { dirname as dirname2, resolve as resolve2 } from "node:path";
import { createClient as createLibsqlClient } from "@libsql/client";

// apps/api/src/persistence/schema.ts
var SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS companies (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  website TEXT,
  address TEXT,
  city TEXT,
  latitude REAL,
  longitude REAL,
  sector TEXT,
  source_urls TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id),
  source_url TEXT NOT NULL,
  source_title TEXT NOT NULL,
  source_type TEXT NOT NULL,
  excerpt TEXT NOT NULL,
  detected_at TEXT NOT NULL,
  published_at TEXT,
  raw_text_hash TEXT NOT NULL,
  confidence REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_evidence_company ON evidence(company_id);

CREATE TABLE IF NOT EXISTS signals (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id),
  evidence_ids TEXT NOT NULL,
  type TEXT NOT NULL,
  description TEXT NOT NULL,
  estimated_impact_class TEXT NOT NULL,
  confidence REAL NOT NULL,
  detected_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_signals_company ON signals(company_id);

CREATE TABLE IF NOT EXISTS opportunities (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id),
  signal_ids TEXT NOT NULL,
  status TEXT NOT NULL,
  score REAL NOT NULL,
  confidence REAL NOT NULL,
  congestion_context TEXT,
  grid_neighbor_status TEXT NOT NULL,
  recommended_next_step TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_opps_company ON opportunities(company_id);

CREATE TABLE IF NOT EXISTS decisions (
  id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL REFERENCES opportunities(id),
  decision_type TEXT NOT NULL,
  reason TEXT NOT NULL,
  policy_version TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_decisions_opp ON decisions(opportunity_id);

CREATE TABLE IF NOT EXISTS activity_log (
  id TEXT PRIMARY KEY,
  opportunity_id TEXT,
  event_type TEXT NOT NULL,
  message TEXT NOT NULL,
  metadata TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_activity_opp ON activity_log(opportunity_id);
CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_log(created_at);

CREATE TABLE IF NOT EXISTS run_history (
  id TEXT PRIMARY KEY,
  trigger TEXT NOT NULL,
  source_provider TEXT NOT NULL,
  extractor TEXT NOT NULL,
  automation_provider TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT NOT NULL,
  sources_discovered INTEGER NOT NULL,
  companies_processed INTEGER NOT NULL,
  signals_detected INTEGER NOT NULL,
  opportunities_created INTEGER NOT NULL,
  actions_dispatched INTEGER NOT NULL,
  actions_blocked INTEGER NOT NULL,
  failures INTEGER NOT NULL,
  incomplete INTEGER NOT NULL DEFAULT 0,
  decisions TEXT NOT NULL DEFAULT '{}',
  notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_started ON run_history(started_at);

CREATE TABLE IF NOT EXISTS dossiers (
  id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL UNIQUE REFERENCES opportunities(id),
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS action_queue (
  id TEXT PRIMARY KEY,
  opportunity_id TEXT NOT NULL REFERENCES opportunities(id),
  action_type TEXT NOT NULL,
  status TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  reason TEXT NOT NULL,
  metadata TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  dispatched_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_queue_opp ON action_queue(opportunity_id);
CREATE INDEX IF NOT EXISTS idx_queue_status ON action_queue(status);

CREATE TABLE IF NOT EXISTS grid_events (
  id TEXT PRIMARY KEY,
  operator TEXT NOT NULL,
  event_type TEXT NOT NULL,
  regions TEXT NOT NULL DEFAULT '[]',
  municipalities TEXT NOT NULL DEFAULT '[]',
  stations TEXT NOT NULL DEFAULT '[]',
  direction TEXT NOT NULL,
  summary TEXT NOT NULL,
  evidence_excerpt TEXT NOT NULL,
  source_url TEXT NOT NULL,
  published_at TEXT,
  detected_at TEXT NOT NULL,
  confidence REAL NOT NULL,
  content_hash TEXT NOT NULL,
  UNIQUE(source_url, content_hash)
);
CREATE INDEX IF NOT EXISTS idx_grid_events_source ON grid_events(source_url);
CREATE INDEX IF NOT EXISTS idx_grid_events_detected ON grid_events(detected_at);
`;

// apps/api/src/persistence/sqlClient.ts
var nodeRequire = createRequire(import.meta.url);
var cachedSqlite = null;
function loadNodeSqlite() {
  if (!cachedSqlite) {
    cachedSqlite = nodeRequire("node:sqlite");
  }
  return cachedSqlite;
}
function createNodeSqliteClient(opts) {
  const { DatabaseSync } = loadNodeSqlite();
  const path = opts.path === ":memory:" ? ":memory:" : resolve2(opts.path);
  if (path !== ":memory:") {
    mkdirSync(dirname2(path), { recursive: true });
  }
  const db = new DatabaseSync(path);
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec(SCHEMA_SQL);
  return {
    async execute(sql, params = []) {
      const stmt = db.prepare(sql);
      stmt.run(...params);
    },
    async get(sql, params = []) {
      const stmt = db.prepare(sql);
      const row = stmt.get(...params);
      return row ?? void 0;
    },
    async all(sql, params = []) {
      const stmt = db.prepare(sql);
      return stmt.all(...params);
    },
    async exec(sql) {
      db.exec(sql);
    },
    async close() {
      db.close();
    }
  };
}
async function createLibsqlSqlClient(opts) {
  const client = createLibsqlClient({
    url: opts.url,
    authToken: opts.authToken,
    // Force integer columns to JS numbers instead of BigInt so downstream
    // Zod schemas that expect `z.number()` keep working. Safe for the
    // low-cardinality counters we store (INTEGER but always < 2^53).
    intMode: "number"
  });
  await client.executeMultiple(SCHEMA_SQL);
  return {
    async execute(sql, params = []) {
      await client.execute({ sql, args: params });
    },
    async get(sql, params = []) {
      const res = await client.execute({ sql, args: params });
      const row = res.rows[0];
      return row ? rowToObject(row, res.columns) : void 0;
    },
    async all(sql, params = []) {
      const res = await client.execute({ sql, args: params });
      return res.rows.map((r) => rowToObject(r, res.columns));
    },
    async exec(sql) {
      await client.executeMultiple(sql);
    },
    async close() {
      client.close();
    }
  };
}
function rowToObject(row, columns) {
  const src = row;
  const out = {};
  for (const col of columns) {
    const v = src[col];
    if (v === null || v === void 0) {
      out[col] = null;
    } else if (typeof v === "bigint") {
      out[col] = Number(v);
    } else if (v instanceof Uint8Array) {
      out[col] = Buffer.from(v).toString("utf8");
    } else {
      out[col] = v;
    }
  }
  return out;
}

// apps/api/src/persistence/companyRepo.ts
import { CompanySchema } from "@netruimte/shared";
function toDomain(row) {
  return CompanySchema.parse({
    id: row.id,
    name: row.name,
    website: row.website,
    address: row.address,
    city: row.city,
    latitude: row.latitude,
    longitude: row.longitude,
    sector: row.sector,
    sourceUrls: JSON.parse(row.source_urls),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  });
}
var UPSERT_SQL = `
  INSERT INTO companies (id, name, website, address, city, latitude, longitude, sector, source_urls, created_at, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET
    name=excluded.name,
    website=excluded.website,
    address=excluded.address,
    city=excluded.city,
    latitude=excluded.latitude,
    longitude=excluded.longitude,
    sector=excluded.sector,
    source_urls=excluded.source_urls,
    updated_at=excluded.updated_at
`;
function createCompanyRepository(db) {
  return {
    async upsert(company) {
      const c = CompanySchema.parse(company);
      await db.execute(UPSERT_SQL, [
        c.id,
        c.name,
        c.website,
        c.address,
        c.city,
        c.latitude,
        c.longitude,
        c.sector,
        JSON.stringify(c.sourceUrls),
        c.createdAt,
        c.updatedAt
      ]);
      return c;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM companies WHERE id = ?`, [id]);
      return row ? toDomain(row) : null;
    },
    async findByName(name) {
      const row = await db.get(`SELECT * FROM companies WHERE name = ?`, [name]);
      return row ? toDomain(row) : null;
    },
    async list() {
      const rows = await db.all(`SELECT * FROM companies ORDER BY created_at DESC`);
      return rows.map(toDomain);
    }
  };
}

// apps/api/src/persistence/evidenceRepo.ts
import { EvidenceSchema } from "@netruimte/shared";
function toDomain2(row) {
  return EvidenceSchema.parse({
    id: row.id,
    companyId: row.company_id,
    sourceUrl: row.source_url,
    sourceTitle: row.source_title,
    sourceType: row.source_type,
    excerpt: row.excerpt,
    detectedAt: row.detected_at,
    publishedAt: row.published_at,
    rawTextHash: row.raw_text_hash,
    confidence: row.confidence
  });
}
var INSERT_SQL = `
  INSERT INTO evidence (id, company_id, source_url, source_title, source_type, excerpt, detected_at, published_at, raw_text_hash, confidence)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`;
function createEvidenceRepository(db) {
  return {
    async insert(evidence) {
      const e = EvidenceSchema.parse(evidence);
      await db.execute(INSERT_SQL, [
        e.id,
        e.companyId,
        e.sourceUrl,
        e.sourceTitle,
        e.sourceType,
        e.excerpt,
        e.detectedAt,
        e.publishedAt,
        e.rawTextHash,
        e.confidence
      ]);
      return e;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM evidence WHERE id = ?`, [id]);
      return row ? toDomain2(row) : null;
    },
    async listByCompany(companyId) {
      const rows = await db.all(
        `SELECT * FROM evidence WHERE company_id = ? ORDER BY detected_at DESC`,
        [companyId]
      );
      return rows.map(toDomain2);
    }
  };
}

// apps/api/src/persistence/signalRepo.ts
import { SignalSchema } from "@netruimte/shared";
function toDomain3(row) {
  return SignalSchema.parse({
    id: row.id,
    companyId: row.company_id,
    evidenceIds: JSON.parse(row.evidence_ids),
    type: row.type,
    description: row.description,
    estimatedImpactClass: row.estimated_impact_class,
    confidence: row.confidence,
    detectedAt: row.detected_at
  });
}
var INSERT_SQL2 = `
  INSERT INTO signals (id, company_id, evidence_ids, type, description, estimated_impact_class, confidence, detected_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`;
function createSignalRepository(db) {
  return {
    async insert(signal) {
      const s = SignalSchema.parse(signal);
      await db.execute(INSERT_SQL2, [
        s.id,
        s.companyId,
        JSON.stringify(s.evidenceIds),
        s.type,
        s.description,
        s.estimatedImpactClass,
        s.confidence,
        s.detectedAt
      ]);
      return s;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM signals WHERE id = ?`, [id]);
      return row ? toDomain3(row) : null;
    },
    async listByCompany(companyId) {
      const rows = await db.all(
        `SELECT * FROM signals WHERE company_id = ? ORDER BY detected_at DESC`,
        [companyId]
      );
      return rows.map(toDomain3);
    }
  };
}

// apps/api/src/persistence/opportunityRepo.ts
import { OpportunitySchema } from "@netruimte/shared";
function toDomain4(row) {
  return OpportunitySchema.parse({
    id: row.id,
    companyId: row.company_id,
    signalIds: JSON.parse(row.signal_ids),
    status: row.status,
    score: row.score,
    confidence: row.confidence,
    congestionContext: row.congestion_context ? JSON.parse(row.congestion_context) : null,
    gridNeighborStatus: row.grid_neighbor_status,
    recommendedNextStep: row.recommended_next_step,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  });
}
var INSERT_SQL3 = `
  INSERT INTO opportunities (id, company_id, signal_ids, status, score, confidence, congestion_context, grid_neighbor_status, recommended_next_step, created_at, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`;
var UPDATE_SQL = `
  UPDATE opportunities SET
    signal_ids=?, status=?, score=?, confidence=?,
    congestion_context=?, grid_neighbor_status=?, recommended_next_step=?,
    updated_at=?
  WHERE id=?
`;
function createOpportunityRepository(db) {
  return {
    async insert(opportunity) {
      const o = OpportunitySchema.parse(opportunity);
      await db.execute(INSERT_SQL3, [
        o.id,
        o.companyId,
        JSON.stringify(o.signalIds),
        o.status,
        o.score,
        o.confidence,
        o.congestionContext ? JSON.stringify(o.congestionContext) : null,
        o.gridNeighborStatus,
        o.recommendedNextStep,
        o.createdAt,
        o.updatedAt
      ]);
      return o;
    },
    async update(opportunity) {
      const o = OpportunitySchema.parse(opportunity);
      await db.execute(UPDATE_SQL, [
        JSON.stringify(o.signalIds),
        o.status,
        o.score,
        o.confidence,
        o.congestionContext ? JSON.stringify(o.congestionContext) : null,
        o.gridNeighborStatus,
        o.recommendedNextStep,
        o.updatedAt,
        o.id
      ]);
      return o;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM opportunities WHERE id = ?`, [id]);
      return row ? toDomain4(row) : null;
    },
    async findByCompany(companyId) {
      const rows = await db.all(
        `SELECT * FROM opportunities WHERE company_id = ? ORDER BY updated_at DESC`,
        [companyId]
      );
      return rows.map(toDomain4);
    },
    async list() {
      const rows = await db.all(`SELECT * FROM opportunities ORDER BY updated_at DESC`);
      return rows.map(toDomain4);
    }
  };
}

// apps/api/src/persistence/decisionRepo.ts
import { DecisionSchema } from "@netruimte/shared";
function toDomain5(row) {
  return DecisionSchema.parse({
    id: row.id,
    opportunityId: row.opportunity_id,
    decisionType: row.decision_type,
    reason: row.reason,
    policyVersion: row.policy_version,
    createdAt: row.created_at
  });
}
var INSERT_SQL4 = `
  INSERT INTO decisions (id, opportunity_id, decision_type, reason, policy_version, created_at)
  VALUES (?, ?, ?, ?, ?, ?)
`;
function createDecisionRepository(db) {
  return {
    async insert(decision) {
      const d = DecisionSchema.parse(decision);
      await db.execute(INSERT_SQL4, [
        d.id,
        d.opportunityId,
        d.decisionType,
        d.reason,
        d.policyVersion,
        d.createdAt
      ]);
      return d;
    },
    async listByOpportunity(opportunityId) {
      const rows = await db.all(
        `SELECT * FROM decisions WHERE opportunity_id = ? ORDER BY created_at ASC`,
        [opportunityId]
      );
      return rows.map(toDomain5);
    }
  };
}

// apps/api/src/persistence/activityRepo.ts
import {
  ActivityLogSchema
} from "@netruimte/shared";
function toDomain6(row) {
  return ActivityLogSchema.parse({
    id: row.id,
    opportunityId: row.opportunity_id,
    eventType: row.event_type,
    message: row.message,
    metadata: row.metadata ? JSON.parse(row.metadata) : null,
    createdAt: row.created_at
  });
}
var INSERT_SQL5 = `
  INSERT INTO activity_log (id, opportunity_id, event_type, message, metadata, created_at)
  VALUES (?, ?, ?, ?, ?, ?)
`;
function createActivityLogRepository(db) {
  return {
    async append(log) {
      const l = ActivityLogSchema.parse(log);
      await db.execute(INSERT_SQL5, [
        l.id,
        l.opportunityId,
        l.eventType,
        l.message,
        l.metadata ? JSON.stringify(l.metadata) : null,
        l.createdAt
      ]);
      return l;
    },
    async listByOpportunity(opportunityId) {
      const rows = await db.all(
        `SELECT * FROM activity_log WHERE opportunity_id = ? ORDER BY created_at ASC`,
        [opportunityId]
      );
      return rows.map(toDomain6);
    },
    async listRecent(limit = 100) {
      const rows = await db.all(
        `SELECT * FROM activity_log ORDER BY created_at DESC LIMIT ?`,
        [limit]
      );
      return rows.map(toDomain6);
    }
  };
}

// apps/api/src/persistence/runHistoryRepo.ts
import {
  RunHistorySchema
} from "@netruimte/shared";
function toDomain7(row) {
  return RunHistorySchema.parse({
    id: row.id,
    trigger: row.trigger,
    sourceProvider: row.source_provider,
    extractor: row.extractor,
    automationProvider: row.automation_provider,
    startedAt: row.started_at,
    finishedAt: row.finished_at,
    sourcesDiscovered: row.sources_discovered,
    companiesProcessed: row.companies_processed,
    signalsDetected: row.signals_detected,
    opportunitiesCreated: row.opportunities_created,
    actionsDispatched: row.actions_dispatched,
    actionsBlocked: row.actions_blocked,
    failures: row.failures,
    incomplete: Boolean(row.incomplete),
    decisions: JSON.parse(row.decisions),
    notes: row.notes
  });
}
var INSERT_SQL6 = `
  INSERT INTO run_history (
    id, trigger, source_provider, extractor, automation_provider,
    started_at, finished_at,
    sources_discovered, companies_processed, signals_detected,
    opportunities_created, actions_dispatched, actions_blocked,
    failures, incomplete, decisions, notes
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`;
function createRunHistoryRepository(db) {
  return {
    async insert(run) {
      const r = RunHistorySchema.parse(run);
      await db.execute(INSERT_SQL6, [
        r.id,
        r.trigger,
        r.sourceProvider,
        r.extractor,
        r.automationProvider,
        r.startedAt,
        r.finishedAt,
        r.sourcesDiscovered,
        r.companiesProcessed,
        r.signalsDetected,
        r.opportunitiesCreated,
        r.actionsDispatched,
        r.actionsBlocked,
        r.failures,
        r.incomplete ? 1 : 0,
        JSON.stringify(r.decisions),
        r.notes
      ]);
      return r;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM run_history WHERE id = ?`, [id]);
      return row ? toDomain7(row) : null;
    },
    async list(limit = 100) {
      const rows = await db.all(
        `SELECT * FROM run_history ORDER BY started_at DESC LIMIT ?`,
        [limit]
      );
      return rows.map(toDomain7);
    }
  };
}

// apps/api/src/persistence/dossierRepo.ts
import { DossierSchema } from "@netruimte/shared";
function toDomain8(row) {
  return DossierSchema.parse({
    id: row.id,
    opportunityId: row.opportunity_id,
    content: JSON.parse(row.content),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  });
}
var UPSERT_SQL2 = `
  INSERT INTO dossiers (id, opportunity_id, content, created_at, updated_at)
  VALUES (?, ?, ?, ?, ?)
  ON CONFLICT(opportunity_id) DO UPDATE SET
    content = excluded.content,
    updated_at = excluded.updated_at
`;
function createDossierRepository(db) {
  return {
    async upsert(dossier) {
      const d = DossierSchema.parse(dossier);
      await db.execute(UPSERT_SQL2, [
        d.id,
        d.opportunityId,
        JSON.stringify(d.content),
        d.createdAt,
        d.updatedAt
      ]);
      return d;
    },
    async findByOpportunity(opportunityId) {
      const row = await db.get(`SELECT * FROM dossiers WHERE opportunity_id = ?`, [
        opportunityId
      ]);
      return row ? toDomain8(row) : null;
    }
  };
}

// apps/api/src/persistence/actionQueueRepo.ts
import {
  QueuedActionSchema
} from "@netruimte/shared";
function toDomain9(row) {
  return QueuedActionSchema.parse({
    id: row.id,
    opportunityId: row.opportunity_id,
    actionType: row.action_type,
    status: row.status,
    attempts: row.attempts,
    reason: row.reason,
    metadata: row.metadata ? JSON.parse(row.metadata) : null,
    lastError: row.last_error,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    dispatchedAt: row.dispatched_at
  });
}
var ENQUEUE_SQL = `
  INSERT INTO action_queue (
    id, opportunity_id, action_type, status, attempts, reason, metadata,
    last_error, created_at, updated_at, dispatched_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`;
var UPDATE_SQL2 = `
  UPDATE action_queue SET
    action_type=?, status=?, attempts=?, reason=?, metadata=?,
    last_error=?, updated_at=?, dispatched_at=?
  WHERE id=?
`;
function createActionQueueRepository(db) {
  return {
    async enqueue(action) {
      const a = QueuedActionSchema.parse(action);
      await db.execute(ENQUEUE_SQL, [
        a.id,
        a.opportunityId,
        a.actionType,
        a.status,
        a.attempts,
        a.reason,
        a.metadata ? JSON.stringify(a.metadata) : null,
        a.lastError,
        a.createdAt,
        a.updatedAt,
        a.dispatchedAt
      ]);
      return a;
    },
    async update(action) {
      const a = QueuedActionSchema.parse(action);
      await db.execute(UPDATE_SQL2, [
        a.actionType,
        a.status,
        a.attempts,
        a.reason,
        a.metadata ? JSON.stringify(a.metadata) : null,
        a.lastError,
        a.updatedAt,
        a.dispatchedAt,
        a.id
      ]);
      return a;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM action_queue WHERE id = ?`, [id]);
      return row ? toDomain9(row) : null;
    },
    async listByOpportunity(opportunityId) {
      const rows = await db.all(
        `SELECT * FROM action_queue WHERE opportunity_id = ? ORDER BY created_at ASC`,
        [opportunityId]
      );
      return rows.map(toDomain9);
    },
    async listByStatus(status) {
      const rows = await db.all(
        `SELECT * FROM action_queue WHERE status = ? ORDER BY created_at ASC`,
        [status]
      );
      return rows.map(toDomain9);
    }
  };
}

// apps/api/src/persistence/gridEventRepo.ts
import { GridEventSchema } from "@netruimte/shared";
function toDomain10(row) {
  return GridEventSchema.parse({
    id: row.id,
    operator: row.operator,
    eventType: row.event_type,
    regions: JSON.parse(row.regions),
    municipalities: JSON.parse(row.municipalities),
    stations: JSON.parse(row.stations),
    direction: row.direction,
    summary: row.summary,
    evidenceExcerpt: row.evidence_excerpt,
    sourceUrl: row.source_url,
    publishedAt: row.published_at,
    detectedAt: row.detected_at,
    confidence: row.confidence,
    contentHash: row.content_hash
  });
}
var INSERT_SQL7 = `
  INSERT INTO grid_events (
    id, operator, event_type, regions, municipalities, stations,
    direction, summary, evidence_excerpt, source_url,
    published_at, detected_at, confidence, content_hash
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`;
function createGridEventRepository(db) {
  return {
    async insert(event) {
      const e = GridEventSchema.parse(event);
      await db.execute(INSERT_SQL7, [
        e.id,
        e.operator,
        e.eventType,
        JSON.stringify(e.regions),
        JSON.stringify(e.municipalities),
        JSON.stringify(e.stations),
        e.direction,
        e.summary,
        e.evidenceExcerpt,
        e.sourceUrl,
        e.publishedAt,
        e.detectedAt,
        e.confidence,
        e.contentHash
      ]);
      return e;
    },
    async findById(id) {
      const row = await db.get(`SELECT * FROM grid_events WHERE id = ?`, [id]);
      return row ? toDomain10(row) : null;
    },
    async findLatestBySourceUrl(sourceUrl) {
      const row = await db.get(
        `SELECT * FROM grid_events WHERE source_url = ? ORDER BY detected_at DESC LIMIT 1`,
        [sourceUrl]
      );
      return row ? toDomain10(row) : null;
    },
    async findBySourceAndHash(sourceUrl, contentHash) {
      const row = await db.get(
        `SELECT * FROM grid_events WHERE source_url = ? AND content_hash = ? LIMIT 1`,
        [sourceUrl, contentHash]
      );
      return row ? toDomain10(row) : null;
    },
    async list(limit = 100) {
      const rows = await db.all(
        `SELECT * FROM grid_events ORDER BY detected_at DESC LIMIT ?`,
        [limit]
      );
      return rows.map(toDomain10);
    }
  };
}

// apps/api/src/persistence/db.ts
function openDb(opts) {
  return createNodeSqliteClient({ path: opts.path });
}

// apps/api/src/persistence/index.ts
function createRepositories(db) {
  return {
    companies: createCompanyRepository(db),
    evidence: createEvidenceRepository(db),
    signals: createSignalRepository(db),
    opportunities: createOpportunityRepository(db),
    decisions: createDecisionRepository(db),
    activity: createActivityLogRepository(db),
    runs: createRunHistoryRepository(db),
    dossiers: createDossierRepository(db),
    actionQueue: createActionQueueRepository(db),
    gridEvents: createGridEventRepository(db)
  };
}
async function openLibsqlDb(opts) {
  return createLibsqlSqlClient(opts);
}

// apps/api/src/context.ts
var here2 = dirname3(fileURLToPath2(import.meta.url));
var DEMO_SOURCES_DIR2 = resolve3(here2, "../../../data/demo/sources");
async function createContext(opts = {}) {
  const demoMode = opts.demoMode ?? (process.env.DEMO_MODE ?? "true").toLowerCase() === "true";
  const serviceToken = process.env.SERVICE_TOKEN?.trim() || null;
  const notificationAllowlist = parseAllowlist(process.env.NOTIFICATION_ALLOWLIST);
  const providerEnv = process.env.DATABASE_PROVIDER?.trim().toLowerCase();
  const wantsTurso = providerEnv === "turso" || providerEnv === void 0 && Boolean(process.env.TURSO_DATABASE_URL);
  let db;
  let databaseProvider;
  let databaseProviderReason;
  if (wantsTurso) {
    const url = process.env.TURSO_DATABASE_URL?.trim();
    if (!url) {
      throw new Error(
        "DATABASE_PROVIDER=turso but TURSO_DATABASE_URL is not set. Configure a libsql:// URL from the Turso dashboard."
      );
    }
    db = await openLibsqlDb({ url, authToken: process.env.TURSO_AUTH_TOKEN?.trim() });
    databaseProvider = "turso";
    databaseProviderReason = providerEnv ? "DATABASE_PROVIDER=turso" : "auto \u2014 TURSO_DATABASE_URL present";
  } else {
    const sqlitePath = opts.sqlitePath ?? process.env.SQLITE_PATH ?? ":memory:";
    db = openDb({ path: sqlitePath });
    databaseProvider = "sqlite";
    databaseProviderReason = providerEnv ? `DATABASE_PROVIDER=sqlite (path=${sqlitePath})` : `auto \u2014 no TURSO_DATABASE_URL (path=${sqlitePath})`;
  }
  const repos = createRepositories(db);
  const wiring = {
    demoMode,
    extractor: "",
    extractorReason: "",
    aiProvider: "rules",
    sourceProvider: "",
    sourceProviderReason: "",
    automationProvider: "",
    automationProviderReason: "",
    gridProvider: "demo",
    gridProviderReason: "",
    databaseProvider,
    databaseProviderReason,
    notificationAllowlist: notificationAllowlist.length,
    scheduledEndpointEnabled: Boolean(serviceToken)
  };
  let sources;
  if (opts.overrides?.sources) {
    sources = opts.overrides.sources;
    wiring.sourceProvider = sources.name;
    wiring.sourceProviderReason = "test override";
  } else if (process.env.APIFY_TOKEN && (process.env.APIFY_ACTOR_ID || process.env.APIFY_DATASET_ID)) {
    const startUrls = parseStartUrls(process.env.APIFY_START_URLS);
    const actorInput = parseActorInput(process.env.APIFY_ACTOR_INPUT);
    sources = new ApifySourceDiscoveryProvider({
      token: process.env.APIFY_TOKEN,
      actorId: process.env.APIFY_ACTOR_ID ?? "",
      datasetId: process.env.APIFY_DATASET_ID ?? void 0,
      startUrls,
      actorInput,
      onEvent: (event, meta) => {
        void repos.activity.append({
          id: newId.activity(),
          opportunityId: null,
          eventType: event === "apify.error" ? "RETRY_FAILED" : event === "apify.run.terminal" ? "SOURCE_DISCOVERED" : "SCAN_STARTED",
          message: `[apify] ${event}`,
          metadata: { ...meta, event },
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        }).catch(() => void 0);
      }
    });
    wiring.sourceProvider = "apify";
    wiring.sourceProviderReason = [
      "APIFY_TOKEN + actor/dataset id present",
      actorInput ? "input=APIFY_ACTOR_INPUT (raw JSON)" : startUrls.length > 0 ? `input=APIFY_START_URLS (${startUrls.length} url${startUrls.length === 1 ? "" : "s"})` : "input=empty (no APIFY_START_URLS or APIFY_ACTOR_INPUT set \u2014 actor will run with empty input)"
    ].join("; ");
  } else {
    if (!demoMode) {
      throw new Error(
        "No source provider configured. Set APIFY_TOKEN + APIFY_ACTOR_ID or run with DEMO_MODE=true."
      );
    }
    sources = new DemoSourceDiscoveryProvider2(DEMO_SOURCES_DIR2);
    wiring.sourceProvider = "demo";
    wiring.sourceProviderReason = "DEMO_MODE=true, no Apify credentials";
  }
  let extractor;
  if (opts.overrides?.extractor) {
    extractor = opts.overrides.extractor;
    wiring.extractor = extractor.name;
    wiring.extractorReason = "test override";
    wiring.aiProvider = "rules";
  } else {
    const selection = chooseEvidenceExtractor({
      env: {
        AI_PROVIDER: process.env.AI_PROVIDER,
        ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
        ANTHROPIC_MODEL: process.env.ANTHROPIC_MODEL,
        OPENAI_API_KEY: process.env.OPENAI_API_KEY,
        OPENAI_MODEL: process.env.OPENAI_MODEL,
        OPENAI_BASE_URL: process.env.OPENAI_BASE_URL,
        GEMINI_API_KEY: process.env.GEMINI_API_KEY,
        GEMINI_MODEL: process.env.GEMINI_MODEL
      },
      onFallback: (err, source) => {
        console.warn(
          `[extractor] AI provider failed on ${source.url} \u2014 falling back to rule-based:`,
          err.message
        );
      }
    });
    extractor = selection.extractor;
    wiring.extractor = selection.providerName;
    wiring.extractorReason = selection.reason;
    wiring.aiProvider = selection.aiProvider;
  }
  let grid;
  if (opts.overrides?.grid) {
    grid = opts.overrides.grid;
    wiring.gridProvider = grid.name === "netbeheer-nl" ? "netbeheer-nl" : "demo";
    wiring.gridProviderReason = "test override";
  } else {
    const gridPreference = (process.env.GRID_PROVIDER ?? "auto").trim().toLowerCase();
    if (gridPreference === "demo") {
      grid = new DemoGridContextProvider2();
      wiring.gridProvider = "demo";
      wiring.gridProviderReason = "GRID_PROVIDER=demo \u2014 static city table";
    } else if (gridPreference === "netbeheer-nl" || gridPreference === "nbnl") {
      grid = new NetbeheerNlGridContextProvider();
      wiring.gridProvider = "netbeheer-nl";
      wiring.gridProviderReason = `GRID_PROVIDER=netbeheer-nl \u2014 live PDOK geocoding + Netbeheer NL snapshot (${NETBEHEER_NL_SNAPSHOT_AT})`;
    } else {
      if (demoMode) {
        grid = new DemoGridContextProvider2();
        wiring.gridProvider = "demo";
        wiring.gridProviderReason = "DEMO_MODE=true \u2014 using deterministic demo table";
      } else {
        grid = new NetbeheerNlGridContextProvider();
        wiring.gridProvider = "netbeheer-nl";
        wiring.gridProviderReason = `auto \u2014 live PDOK geocoding + Netbeheer NL snapshot (${NETBEHEER_NL_SNAPSHOT_AT})`;
      }
    }
  }
  let automation;
  if (opts.overrides?.automation) {
    automation = opts.overrides.automation;
    wiring.automationProvider = automation.name;
    wiring.automationProviderReason = "test override";
  } else if (process.env.N8N_BASE_URL) {
    automation = new N8nAutomationClient({
      baseUrl: process.env.N8N_BASE_URL,
      webhookToken: process.env.N8N_WEBHOOK_TOKEN,
      notificationAllowlist
    });
    wiring.automationProvider = "n8n";
    wiring.automationProviderReason = `N8N_BASE_URL present, allowlist=${notificationAllowlist.length}`;
  } else if (demoMode) {
    automation = new LocalAutomationProvider2();
    wiring.automationProvider = "local";
    wiring.automationProviderReason = "DEMO_MODE=true, no N8N_BASE_URL";
  } else {
    automation = new DisabledAutomationProvider();
    wiring.automationProvider = "disabled";
    wiring.automationProviderReason = "no automation provider configured";
  }
  const runService = new AutonomousRunService2({
    repos,
    sources,
    extractor,
    grid,
    scoring: new OpportunityScoringService2(),
    policy: new PolicyEngine2(),
    automation
  });
  const dossierService = new OpportunityDossierService(repos);
  const buildOfflineRunService = () => {
    const offlineSources = new DemoSourceDiscoveryProvider2(DEMO_SOURCES_DIR2);
    const offlineAutomation = new LocalAutomationProvider2();
    return new AutonomousRunService2({
      repos,
      sources: offlineSources,
      extractor: new RuleBasedEvidenceExtractor2(),
      grid: new DemoGridContextProvider2(),
      scoring: new OpportunityScoringService2(),
      policy: new PolicyEngine2(),
      automation: offlineAutomation
    });
  };
  return {
    repos,
    demoMode,
    serviceToken,
    sources,
    extractor,
    grid,
    automation,
    runService,
    dossierService,
    wiring,
    buildOfflineRunService,
    resetDb: () => resetDb(db)
  };
}
async function resetDb(db) {
  const tables = [
    "action_queue",
    "decisions",
    "activity_log",
    "dossiers",
    "run_history",
    "opportunities",
    "signals",
    "evidence",
    "grid_events",
    "companies"
  ];
  for (const t of tables) {
    await db.execute(`DELETE FROM ${t}`);
  }
}
function parseAllowlist(raw) {
  if (!raw) return [];
  return raw.split(",").map((s) => s.trim()).filter((s) => s.length > 0);
}
function parseStartUrls(raw) {
  if (!raw) return [];
  return raw.split(",").map((s) => s.trim()).filter((s) => s.length > 0);
}
function parseActorInput(raw) {
  if (!raw) return void 0;
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return parsed;
    }
    console.warn("[context] APIFY_ACTOR_INPUT must be a JSON object; ignoring");
    return void 0;
  } catch (err) {
    console.warn("[context] APIFY_ACTOR_INPUT is not valid JSON; ignoring:", err.message);
    return void 0;
  }
}

// netlify/functions/api.ts
var appP = null;
async function getApp() {
  if (!appP) {
    appP = (async () => {
      const ctx = await createContext();
      const app = createApp(ctx);
      app.get(
        "/api/health",
        (c) => c.json({
          status: "ok",
          service: "netruimte-radar-api",
          demoMode: ctx.demoMode,
          databaseProvider: ctx.wiring.databaseProvider,
          time: (/* @__PURE__ */ new Date()).toISOString()
        })
      );
      return app;
    })().catch((err) => {
      appP = null;
      throw err;
    });
  }
  return appP;
}
var api_default = async (request) => (await getApp()).fetch(request);
var config = {
  path: "/api/*"
};
export {
  config,
  api_default as default
};
